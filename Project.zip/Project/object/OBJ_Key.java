package object;

import javax.imageio.ImageIO;

public class OBJ_Key extends superObject {

    public OBJ_Key() {
        name = "key";
        try {
            image = ImageIO.read(getClass().getResourceAsStream("/Objects/key.png"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
