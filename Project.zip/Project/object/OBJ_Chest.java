package object;

import javax.imageio.ImageIO;

public class OBJ_Chest extends superObject {
    public OBJ_Chest() {
        name = "key";
        try {
            image = ImageIO.read(getClass().getResourceAsStream("/Objects/chest.png"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
