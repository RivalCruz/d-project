package object;

import javax.imageio.ImageIO;

public class OBJ_Door extends superObject {

    public OBJ_Door() {
        name = "key";
        try {
            image = ImageIO.read(getClass().getResourceAsStream("/Objects/door.png"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
