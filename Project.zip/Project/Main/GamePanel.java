package Main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

import Entity.Player;
import object.superObject;
import tile.TileManager;

public class GamePanel extends JPanel implements Runnable {

    // Screen settings

    final int originalTileSize = 16; // player character 16 x 16 pixels(standard size for character in 2d game)
    final int scale = 3; // scale for high resolutions computer -> 16 x 3 = 48 pixels

    public final int tileSize = originalTileSize * scale; // 16 x 3 = 48 pixels
    public final int maxScreenCol = 16; // 16 pixels horizontal
    public final int maxScreenRow = 12; // 12 pixels vertical
    public final int screenWidht = tileSize * maxScreenCol; // 48 x 16 = 768 pixels for widht screen
    public final int screenHeight = tileSize * maxScreenRow; // 48 x 12 = 576 pixels for height screen

    TileManager tileM = new TileManager(this);
    KeyHandler keyH = new KeyHandler();

    Thread gameThread; // buat nebe mak ita bele hahu no hapara

    public CollisionChecker cChecker = new CollisionChecker(this);

    public AssetSetter aSetter = new AssetSetter(this);

    public Player player = new Player(this, keyH);

    public superObject obj[] = new superObject[10];

    // WORLD SETTINGS
    public final int maxWorldCol = 50;
    public final int maxWorldRow = 50;
    public final int worldWidht = tileSize * maxWorldCol;
    public final int worldHeight = tileSize * maxWorldRow;

    // FPS
    int FPS = 60;

    /*
     * // set player default position
     * int playerX = 100;
     * int playerY = 100;
     * int playerSpeed = 4;
     */

    public GamePanel() {

        this.setPreferredSize(new Dimension(screenWidht, screenHeight));// set the size of JPanel
        this.setBackground(Color.black); // JPanel bg color
        this.setDoubleBuffered(true); // if set true, all the drawing from this component will be done in an offscreen
                                      // painting Buffer
                                      // in short, enabling this can improve game's rendering performance
        this.addKeyListener(keyH);
        this.setFocusable(true);

    }

    public void setupGame() {

        aSetter.setObject();
    }

    public void startGameThread() {

        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run() {
        double drawInterval = 1000000000 / FPS; // 0.0166666 seconds
        double nextDrawTime = System.nanoTime() + drawInterval;

        while (gameThread != null) {

            // UPDATE -> to update information such as character position
            update();

            // DRAW -> to draw the screen with the updated information
            repaint(); // to call paintComponent method

            try {
                double remainingTime = nextDrawTime - System.nanoTime();
                remainingTime = remainingTime / 1000000; // convert remainingTime to milisecond

                if (remainingTime < 0) {
                    remainingTime = 0;
                }

                Thread.sleep((long) remainingTime);

                nextDrawTime += drawInterval;

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void update() {
        player.update();
    }

    public void paintComponent(Graphics g) {

        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g; // change graphics g to graphics2D

        // TILE
        tileM.draw(g2);

        // OBJECT
        for (int i = 0; i < obj.length; i++) {
            if (obj[i] != null) {
                obj[i].draw(g2, this);
            }
        }

        // PLAYER
        player.draw(g2);

        g2.dispose();
    }

}
